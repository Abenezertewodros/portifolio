 (function(){
            emailjs.init("zIaBfY84Q8sgiBace"); // Replace with your EmailJS public key
        })();

        document.getElementById("contact").addEventListener("submit", function(event){
            event.preventDefault();

            emailjs.send("service_785mw5k", "template_yhu68hc", {
                name: document.getElementById("name").value,
                email: document.getElementById("email").value,
                message: document.getElementById("message").value
              
            })
            .then(response => {
                alert("Message sent successfully!");
                document.getElementById("contact-form").reset();
            })
            .catch(error => {
                alert("Failed to send message. Please try again!");
                console.error("EmailJS Error:", error);
            });
        });